<?php if ( !defined( 'ABSPATH' ) ) die( "Cannot access files directly." ); ?>

<p><?php printf( __( "Do you find this plugin useful? Consider a donation to %sCat Guardians%s, a wonderful no-kill shelter where I volunteer.", 'daves-wordpress-live-search' ), '<a href="http://catguardians.org">', '</a>' ); ?></p>
